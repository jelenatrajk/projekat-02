<?php include "./menu.php"; ?><br>
<?php 
$connect = mysqli_connect("localhost", "root", "", "baza_projekta");

if(isset($_POST['add_to_cart'])){
    if(isset($_SESSION['cart'])){
        $session_array_id = array_column($_SESSION['cart'], "id");

        if(!in_array($_GET['id'], $session_array_id)){
            $session_array = array(
                'id' => $_GET['id'],
                "naziv" => $_POST['naziv'],
                "cena" => $_POST['cena'],
                "kolicina" => $_POST['kolicina']
            );
        }
    }else{
        $session_array = array(
            'id' => $_GET['id'],
            "naziv" => $_POST['naziv'],
            "cena" => $_POST['cena'],
            "kolicina" => $_POST['kolicina']
        );
        $_SESSION['cart'][] = $session_array;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">;
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
   
<div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="text-center">Proizvodi</h2>
                    <div class="col-md-12">
                       <div class="row">
                    <?php 
                    $query = "SELECT * FROM `proizvod`";
                    $result = mysqli_query($connect,$query);

                    while ($row = mysqli_fetch_array($result)) {?>
                    <div class="col-md-4">
                    <form method="post" action="proizvodi.php?id=<?=$row['id'] ?>">
                <img src="img/<?= $row['slika'] ?>" style='height: 150px;'>
                <h5 class="text-center"><?= $row['naziv']; ?></h2>
                <h5 class="text-center">#<?= number_format($row['cena'],2); ?></h5>
                <input type="hidden" name="naziv" value="<?= $row['naziv'] ?>">
                <input type="hidden" name="cena" value="<?= $row['cena'] ?>">
                <input type="number" name="kolicina" value="1" class="form-control">
                <input type="submit" name="add_to_cart" class="btn btn-warning btn-block" value="dodaj u korpu">
                    </form>
                    </div>

                    <?php }
                    ?>
                </div>
                    </div>>
                </div>
                <div class="col-md-6">
                    <h2 class="text-center">korpa</h2>

                    <?php 
                    $output = "";
                    $output .= "
                    <table class='table table-bordered table-striped'>
                    <tr>
                    <th>ID</th>
                    <th>Naziv</th>
                    <th>Cena</th>
                    <th>Kolicina</th>
                    <th>Ukupnp</th>
                    <th>Kol</th>
                    </tr>
                    
                    ";
                    if(!empty($_SESSION['cart'])){
                        foreach($_SESSION['cart'] as $key => $value) {
                            $output .= "
                            <tr>
                            <td>".$value['id']."</td>
                            <td>".$value['naziv']."</td>
                            <td>".$value['cena']."</td>
                            <td>".$value['kolicina']."</td>
                            <td>#".$value['cena'] * $value['kolicina']."</td>
                            <td>
                            <a href='telo.php?action=remove&id=".$value['id']."'>
                            <button class='btn byn-danger btn-block'>Ukloni</button>
                            </a>
                            </td>
                            ";
                            $total = $value['kolicina'] * $value['cena'];
                        }
                        $output .= "
                        <tr>
                        <td colspan='3'></td>
                        <td></b>Ukupno</b></td>
                        <td>".$total."</td>
                        </tr>
                        ";
                    }

                    echo $output;

                    ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    if(isset($_GET['action'])){
        if($_GET['action'] =="obrisi"){
            unset($_SESSION['cart']);
        }
        if($_GET['action'] == "ukloni"){
            foreach($_SESSION['cart'] as $key => $value){
                if($value['id'] == $_GET['id']){
                    unset($_SESSION['cart'][$key]);
                }
            }
        }
    }
    ?>

</body>
</html>