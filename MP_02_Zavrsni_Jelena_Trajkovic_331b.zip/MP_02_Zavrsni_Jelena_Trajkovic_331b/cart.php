<?php include "./menu.php"; ?><br>
<?php 
session_start();
if(isset($_GET['remove'])){
    $id = $_GET['remove'];
    unset($_SESSION['mycart'][$id]);
    header("Location: cart.php");
}
$conn = mysqli_connect("localhost", "root", "", "baza_projekta");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">;
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1 class="text-danger alert-danger">korpa</h1>

        <div class="row">
            <p class="text-right">
                <span><?php
                if(isset($_SESSION['mycart'])){
                    echo "<a href='cart.php'>" .count($_SESSION['mycart']). "</a>";
                }
                      else {
                          echo 0;
                      }
                ?> </span> proizvodi u korpi
            </p>
            <div class="class-md-12 text-center">

            <?php 
            if(!isset($_SESSION['mycart']) || count($_SESSION['mycart']) == 0){
                echo "<h1>Korpa je prazna</h1>";
                echo "<a href='shop.php'>Vrati se u Shop</a>";
            } else{

            
            ?>
                
           <table class="table">
               <thead>
                   <tr>
                       <th>Br.</th>
                       <th>Naziv</th>
                       <th>Cena</th>
                       <th>Kolicina</th>
                       <th>Iznos</th>
                       <th>ac</th>
                    </tr>
               </thead>
               <tbody>
                   <?php 
                   $sn = 1;
                   $total = 0;
                   foreach($_SESSION['mycart'] as $key => $value){
                       $q = mysqli_query($conn, "SELECT * FROM `shop` WHERE id= $key");

                       foreach ($q as $a){
                        echo "<tr>
                        <td>$sn</td>
                        <td>".$a['naziv']."</td>
                        <td>".$a['cena']."</td>
                        <td>".$value['quantity']."</td>
                        <td>".$value['quantity']*$a['cena']."</td>
                        <td><a class='btn btn-danger btn-sm' href='?remove=".$key."'>obrisi</a></td>
                        </tr>";

                        $total += $value['quantity']*$a['cena'];
                       }
                          
                       $sn++;
                   }
                   ?>
               </tbody>
           </table>
          
            </div>
        </div>
        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-6">
                <h1>Ukupno:<?php echo "Rsd: " .$total ?></h1>
                <a href='shop.php'>Vrati se u Shop</a>
            </div>
        </div>
        <?php 
            }
           ?>
    </div>
</body>
</html>