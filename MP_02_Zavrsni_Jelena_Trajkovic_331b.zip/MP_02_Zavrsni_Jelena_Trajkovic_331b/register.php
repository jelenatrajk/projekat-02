<?php include_once 'menu.php'; ?>

<?php
  if(isset($_POST['register'])){
      $username = $_POST['username'];
      $password = $_POST['password'];
      $email = $_POST['email'];

         if($username!='' && $password!='' && $email!=''){

             
             $sql = "INSERT INTO `register`(`username`, `password`, `email`) VALUES ('$username','$password','$email')";

                include_once('db.php');

              $qry = mysqli_query($conn, $sql) or die("data error");
                 if($qry){
                 echo "$username register";
                }
            }
            echo "unesite sve podatke";
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@1,100&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body{
            background-image: url(./slike/sl8.jpeg);
            background-size: cover;
        }
       
        .wrapper{
            background: white;
            padding: 30px 15px;
            width: 370px;
        }
        .wrapper .title{
            border-left: 5px solid wheat;
            padding-left: 5px;
            margin-bottom: 15px;
        }
        .input-field{
            display: block;
            margin: 10px 0;
            width: 100%;
        }
        .input-field .input-label{
            display: block;
            font: 15px;
        }
        .input-field .input{
            font-family: 'Poppins', sans-serif;
            border: 1px solid whitesmoke;
            background: transparent;
            outline: none;
            width: 100%;
            padding: 10px;
            font-size: 15px;
        }
        .input-field .input:focus{
            border-color: burlywood;
        }
        .btn{
            font-family: 'Poppins', sans-serif;
            background: wheat;
            color: black;
            padding: 10px;
            width: 100%;
            font-size: 15px;
            border: 1px solid burlywood;
            cursor: pointer;
            margin: 5px 0;
            transition: 0.3s all ease;
        }
        .btn:hover, .btn:focus{
            text-decoration: none;
            color: burlywood;
            border-color: cadetblue;
        }
        .wrapper .form p{
            margin: 5px 0;
            text-align: center;
        }
        .wrapper .form p a{
            text-decoration: none;
            color: #333;
            transition: 0.3 all ease;
        }
        .wrapper .form p a:focus, .wrapper .form p a:hover{
            color: burlywood;
        }

    </style>
</head>
<body>
<div class="wrapper">
        <h2 class="title">Registruj se!</h2>
        <form action="" method="post" class="form" name="register">
        <div class="input-field">
                <label for="username" class="input-label">Ime</label>
                <input type="text" class="input" placeholder="Unesite vase ime" name="username">
            </div>
            <div class="input-field">
                <label for="email" class="input-label">Email</label>
                <input type="email" id="email" class="input" placeholder="Unesite email" name="email">
            </div>
            <div class="input-field">
                <label for="password" class="input-label">Password</label>
                <input type="password" id="password" class="input" placeholder="Unesite sifru" name="password">
            </div>
            <input type="submit" name="register" value="registruj se" class="btn">
            <p>Vec imate nalog? <a href="login.php">Uloguj se</a></p>
        </form>
    </div>
</body>
</html>