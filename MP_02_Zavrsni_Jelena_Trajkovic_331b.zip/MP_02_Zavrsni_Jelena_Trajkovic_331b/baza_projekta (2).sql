-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 03, 2022 at 01:00 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baza_projekta`
--

-- --------------------------------------------------------

--
-- Table structure for table `kontaktform`
--

DROP TABLE IF EXISTS `kontaktform`;
CREATE TABLE IF NOT EXISTS `kontaktform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `poruka` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `kontaktform`
--

INSERT INTO `kontaktform` (`id`, `ime`, `email`, `poruka`) VALUES
(1, '', 'jelena@email', '['),
(2, '', 'jelena@email', '['),
(3, '', '', '['),
(4, '', '', '['),
(5, '', '', '['),
(6, '', '', '['),
(7, '', '', '['),
(8, '', '', '['),
(9, '', '', '['),
(10, 'ime', 'email@email', '[');

-- --------------------------------------------------------

--
-- Table structure for table `proizvod`
--

DROP TABLE IF EXISTS `proizvod`;
CREATE TABLE IF NOT EXISTS `proizvod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `cena` double NOT NULL,
  `slika` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `proizvod`
--

INSERT INTO `proizvod` (`id`, `naziv`, `cena`, `slika`) VALUES
(1, 'NIVEA Q10 ENERGY', 480.65, '../sllice/sl2.png'),
(2, 'NIVEA Essentials', 580.9, '../sllice/sl3.jpg'),
(3, 'NIVEA AQUA', 520.5, '../sllice/sl4.jpg'),
(4, 'NIVEA Q10 POWER', 680.2, '../sllice/sl5.jpg'),
(5, 'GARNIER HYALURONIC', 520.99, '../sllice/sl6.jpg'),
(6, 'GARNIER Botanical', 538.99, '../sllice/sl7.jpg'),
(7, 'GARNIER BIO', 540.08, '../sllice/sl8.jpg'),
(8, 'GARNIER Anti-Ageing 45+', 650.55, '../sllice/sl9.jpg'),
(9, 'GARNIER Anti-Ageing 55+', 540.8, '../sllice/sl10.jpg'),
(10, 'LOREAL Revitalift', 680.99, '../sllice/sl11.jpg'),
(11, 'LOREAL Revitalift LASER', 780.5, '../sllice/sl12.jpg'),
(12, 'LOREAL Revitalift Day', 650.99, '../sllice/sl13.jpg'),
(13, 'MIXA HYALUROGEL', 580.99, '../sllice/sl14.jpg'),
(14, 'MIXA Sensitiv', 480.99, '../sllice/sl15.jpg'),
(15, 'Eucerin Hyaluron-Filer Day SPF15', 620.5, '../sllice/sl16.jpg'),
(16, 'Eucerin Hyaluron-Filer Day SPF', 653.99, '../sllice/sl17.jpg'),
(17, 'Afrodita CERAMIDES', 480.99, '../sllice/sl19.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

DROP TABLE IF EXISTS `proizvodi`;
CREATE TABLE IF NOT EXISTS `proizvodi` (
  `id_proizvodi` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` text COLLATE utf16_unicode_ci NOT NULL,
  `cena` int(11) NOT NULL,
  `slika` text COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id_proizvodi`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`id_proizvodi`, `naziv`, `cena`, `slika`) VALUES
(1, 'NIVEA Q10 ENERGY', 480, '../sllice/sl2.png'),
(2, 'NIVEA Essentials', 580, '../sllice/sl3.jpg'),
(3, 'NIVEA AQUA', 520, '../sllice/sl4.jpg'),
(4, 'NIVEA Q10 POWER', 680, '../sllice/sl5.jpg'),
(5, 'GARNIER HYALURONIC', 520, '../sllice/sl6.jpg'),
(6, 'GARNIER Botanical', 538, '../sllice/sl7.jpg'),
(7, 'GARNIER BIO', 540, '../sllice/sl8.jpg'),
(8, 'GARNIER Anti-Ageing 45+', 650, '../sllice/sl9.jpg'),
(9, 'GARNIER Anti-Ageing 55+', 540, '../sllice/sl10.jpg'),
(10, 'LOREAL Revitalift', 680, '../sllice/sl11.jpg'),
(11, 'LOREAL Revitalift LASER', 780, '../sllice/sl12.jpg'),
(12, 'LOREAL Revitalift Day', 650, '../sllice/sl13.jpg'),
(13, 'MIXA HYALUROGEL', 580, '../sllice/sl14.jpg'),
(14, 'MIXA Sensitiv', 480, '../sllice/sl15.jpg'),
(15, 'Eucerin Hyaluron-Filer Day SPF15', 620, '../sllice/sl16.jpg'),
(16, 'Eucerin Hyaluron-Filer Day SPF', 653, '../sllice/sl17.jpg'),
(17, 'Afrodita CERAMIDES', 480, '../sllice/sl19.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf16_unicode_ci NOT NULL,
  `password` text COLLATE utf16_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `password`, `email`) VALUES
(1, 'ime', 'unesisifru', 'ime@email'),
(2, 'ime', 'email', 'unesi@email'),
(3, 'jelena', 'jelenaemail', 'jelena@email');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

DROP TABLE IF EXISTS `shop`;
CREATE TABLE IF NOT EXISTS `shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` text COLLATE utf16_unicode_ci NOT NULL,
  `cena` int(11) NOT NULL,
  `slika` text COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`id`, `naziv`, `cena`, `slika`) VALUES
(1, 'Bruno Banani', 8540, './slparfemi/sl1.jpg'),
(2, 'Zoranah', 5320, './slparfemi/sl4.jpg'),
(3, 'Davidoff Cool Water', 6990, './slparfemi/sl5.jpg'),
(4, 'CAROLINA HERRERA Good Girl', 7740, './slparfemi/sl6.jpg'),
(5, 'Black XS Paco Rabanne', 8220, './slparfemi/sl7.jpg'),
(6, 'Gucci Bloom', 5550, './slparfemi/sl8.jpg'),
(7, 'Christina Aguilera EDP', 8540, './slparfemi/sl9.jpg'),
(8, 'JIMMY CHOO', 9290, './slparfemi/sl10.jpg'),
(9, 'ROBERTO CAVALLI', 11540, './slparfemi/sl11.jpg'),
(10, 'Dolce & Gabbana', 10620, './slparfemi/sl12.jpg'),
(11, 'BVLGARI Omnia', 9640, './slparfemi/sl13.jpg'),
(12, 'Escada', 8760, './slparfemi/sl14.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf16_unicode_ci NOT NULL,
  `password` text COLLATE utf16_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
