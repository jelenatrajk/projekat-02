<?php include "./menu.php"; ?><br>

<?php 
if(isset($_POST['btn-send'])){
    $username = $_POST['user'];
    $email = $_POST['email'];
    $comment = $_POST['comment'];

    if(empty($username) || empty($email) || empty($comment)){
        header('location: log.php?error');
    } else{
        $to = "jelena18tr@gmail.com";
        if(mail($to,$comment,$email)){
            header('location:log.php?success');
        }
        
    }
    
} else{
    header('location:log.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
       *{
           margin: 0;
           padding: 0;
           font-family: sans-serif;
       }
       .contact-section{
           background: url(slike/sl8.jpeg) no-repeat center;
           background-size: cover;
           padding: 40px 0;
       }
       .contact-section h1{
           text-align: center;
           color: #34495e;
       }
       .border{
           width: 100px;
           height: 10px;
           background: #34495e;
           margin: 40px auto;
       }
       .contact-form{
           max-width: 600px;
           margin: auto;
           padding: 0 10px;
           overflow: hidden;
       }
       .contact-form-text{
           display: block;
           width: 100%;
           box-sizing: border-box;
           margin: 16px 0;
           border: 0;
           background: #111;
           padding: 20px 40px;
           outline: none;
           color: #ddd;
       }
       textarea.contact-form-text{
           resize: none;
           height: 120px;
       }
       .contact-form-btn{
           float: right;
           border: 0;
           background: #34495e;
           color: #fff;
           padding: 12px 50px;
           border-radius: 20px;
           cursor: pointer;
           transition: 0.5s;
       }
       .contact-form-btn:hover{
           background: #2980b9;
       }
    </style>
</head>
<body>
    <!-- <?php
    // if (isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["textarea"])){
    //     $username = $_POST["username"];
    //     $email = $_POST["email"];
    //     $textarea = $_POST["textarea"];
    //     if($username && $email && $textarea){
    //         echo "Hvala sto ste ostavili komentar! Odgovoricemo u najkracem roku!";
    //     } else {
    //         echo "unesite podatke";
    //     }
    // }
    
    ?> -->

    <div class="contact-section">
        <h1>Kontaktirajte nas</h1>

        <?php 

        $comment = "";
        if(isset($_GET['error'])){
            $comment = "unesite poruku";
            echo '<div class="alert alert-danger">'.$comment.'</div>';
        }
        if(isset($_GET['success'])){
            $comment = "vasa poruka je poslata";
            echo '<div class="alert alert-success">'.$comment.'</div>';
        }
        ?>
        <div class="border"></div>
        <form class="contact-form" action="log.php" method="post">
            <input type="text" class="contact-form-text" name="user" placeholder="Unesite ime">
            <input type="email" class="contact-form-text" name="email" placeholder="Unesite email">
            <textarea name="textarea" class="contact-form-text" name="comment" placeholder="Unesite poruku"></textarea>
            <button type="submit" class="btn btn-success" name="btn-send">Posalji</button>
        </form>
    </div>
    
</body>
</html>