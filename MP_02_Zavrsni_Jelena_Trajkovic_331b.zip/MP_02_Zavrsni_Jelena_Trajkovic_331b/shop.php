<?php include "./menu.php"; ?><br>
<?php 
session_start();
if(isset($_GET['action']) == "add"){
    $id = $_GET['id'];

    if(isset($_SESSION['mycart'])){
        $previus = $_SESSION['mycart'] && [$id]['quantity'];
        $_SESSION['mycart'][$id] = array("id"=>$id,"quantity"=>$previus+$_POST['quantity']);
    } else{
    $_SESSION['mycart'][$id] = array("id"=>$id,"quantity"=>$_POST['quantity']);
    }
  
  header("Location: cart.php");
}

$conn = mysqli_connect("localhost", "root", "", "baza_projekta");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">;
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h1 class="text-danger alert-danger">Dobrodosli u Parfem-shop</h1>
        <form method="post">
                
                <input type="text" name="name" placeholder="pretrazi" id="search">
                <input type="submit" value="posalji">
            </form>

        <div class="row">
            <p class="text-right">
                <span><?php
                if(isset($_SESSION['mycart'])){
                    echo "<a href='cart.php'>" .count($_SESSION['mycart']). "</a>";
                }
                      else {
                          echo 0;
                      }
                ?> </span> proizvodi u korpi
            </p>
            <?php 
            
            $query = "SELECT * FROM `shop`";
            $res = mysqli_query($conn,$query);
            while($row = mysqli_fetch_assoc($res)){
                ?>
            <div class="col-md-4 text-center">
                <form action="shop.php?action=add&id=<?php echo $row["id"]?>" method="post">
                <div class="card">
                    <img src="<?php echo $row["slika"]?>" height="300px" width="400px">
                    <h4><?php echo $row["naziv"]?></h4>
                    <h4><?php echo $row["cena"]?></h4>
                    <input type="number" value="1" name="quantity" placeholder="kolicina" min="0">
                    <input type="submit" value="dodaj u korpu" name="btncart" class="btn btn-success">
                   
                </div>
            </form>
            </div>
            <?php }
            ?>
            
        </div>
    </div>
</body>
</html>