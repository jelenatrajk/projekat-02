<?php include_once 'menu.php'; ?>

<?php 
if(isset($_POST['login'])){

  $username = $_POST['username'];
  $password = $_POST['password'];
  $keep = $_POST['keep'];
  if($keep==1){
    setcookie('uname', $username, time()+60*60*24*7,"/");
    setcookie('password', $password, time()+60*60*24*7,"/");
  }

  $sql = "SELECT * FROM `register`WHERE username='$username' && password='$password'";

  require_once('db.php');

  $qry = mysqli_query($conn, $sql) or die("login error");
  $count = mysqli_num_rows($qry);
  if($count==1){
    $_SESSION['user']= $username;
    header("Location:index.php");
  }

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@1,100&display=swap');
        *{
            margin: 0;
            padding: 0;
            
        }
        body{
            background-image: url(./slike/sl8.jpeg);
            background-size: cover;
        }
        .wrapper{
            background: white;
            padding: 10px 0px;
            width: 470px;
            margin: 10px 0px;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            
        }
        .wrapper .title{
            border-left: 15px solid wheat;
            padding-left: 25px;
            margin-bottom: 15px;
        }
        .input-field{
            display: block;
            margin: 15px 0;
            width: 100%;
        }
        .input-field .input-label{
            display: block;
            font: 15px;
        }
        .input-field .input{
            font-family: 'Poppins', sans-serif;
            border: 1px solid whitesmoke;
            background: transparent;
            outline: none;
            width: 100%;
            padding: 10px;
            font-size: 15px;
        }
        .input-field .input:focus{
            border-color: burlywood;
        }
        .btn{
            font-family: 'Poppins', sans-serif;
            background: wheat;
            color: black;
            padding: 10px;
            width: 100%;
            font-size: 15px;
            border: 1px solid burlywood;
            cursor: pointer;
            margin: 5px 0;
            transition: 0.3s all ease;
        }
        .btn:hover, .btn:focus{
            text-decoration: none;
            color: burlywood;
            border-color: cadetblue;
        }
        .wrapper .form p{
            margin: 5px 0;
            text-align: center;
        }
        .wrapper .form p a{
            text-decoration: none;
            color: #333;
            transition: 0.3 all ease;
        }
        .wrapper .form p a:focus, .wrapper .form p a:hover{
            color: burlywood;
        }
       

    </style>
</head>
<body>
<div class="wrapper">
        <h2 class="title">Login</h2>
        <form action="login.php" method="post" class="form" name="login">
            <div class="input-field">
                <label for="user" class="input-label">Email</label>
                <input type="email" id="user" class="input" name="username" placeholder="Unesite email">
            </div>
            <div class="input-field">
                <label for="pass" class="input-label">Password</label>
                <input type="password" id="pass" class="input" name="password" placeholder="Unesite sifru" required>
            </div>
            <div>
            <label for="keep" >Keep me logged in: </label>
        <input type="checkbox" name="keep" id="keep" />
            </div>
            <input type="submit" class="btn" value="Login" name="login">
            <p>Novi korisnik? <a href="register.php">Registruj se</a></p>
        </form>
    </div>
</body>
</html>
