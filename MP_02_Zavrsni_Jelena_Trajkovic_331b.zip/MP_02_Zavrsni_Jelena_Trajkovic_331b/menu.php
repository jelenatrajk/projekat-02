<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" integrity="sha384-jLKHWM3JRmfMU0A5x5AkjWkw/EYfGUAGagvnfryNV3F9VqM98XiIH7VBGVoxVSc7" crossorigin="anonymous">
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .navbar{
            display: flex;
            align-items: center;
            padding: 20px;

        }
        nav{
            flex: 1;
            text-align: right;
        }
        nav ul{
            display: inline-block;
            list-style-type: none;
            list-style: none;
        }
        nav ul li{
            display: inline-block;
            margin-right: 20px;
            color: black;
            text-decoration: none;
        }
        a{
            text-decoration: none;
            color: #555;
        }
        nav ul li a:hover{
        background: white;
        }
        p{
            color: #555;
        }
        .container{
            max-width: 1300px;
            margin: auto;
            padding-left: 25px;
            padding-right: 25px;
        }
        h3{
            color: violet;
        }
        a{
            line-height: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="navbar">
        <div class="logo">
           <h3>Parfem-shop</h3>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Pocetna</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li><a href="onama.php">O nama</a></li>
                <li><a href="log.php">Kontakt</a></li>
                <li><a href="login.php">Nalog</a></li>
            </ul>
        </nav>
        <a href="cart.php"class="fas fa-shopping-cart"></a>
        <a href="logaut.php"class="fas fa-user"></a>
    </div>
    </div>
</body>
</html>