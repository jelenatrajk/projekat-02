<?php include_once 'menu.php'; ?>

<?php 
include_once('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

  <style>
    .row{
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      justify-content: space-around;
    }
    .col-2{
      flex-basis: 50%;
      min-width: 300px;
    }
    .col-2 img{
      max-width: 100%;
      padding: 50px 0;
    }
    .col-2 h1{
      font-size: 50px;
      line-height: 60px;
      margin: 25px 0;
    }
    .btn{
      display: inline-block;
      background: #ff523b;
      color: #fff;
      padding: 8px 30px;
      margin: 30px 0;
      border-radius: 30px;
    }
    .header{
      background: radial-gradient(#fff,#ffd6d6);
    }
    .header .row{
      margin-top: 70px;

    }
    .categories{
      margin: 70px 0;
    }
    .col-3{
      flex-basis: 30%;
      min-width: 250px;
      margin-bottom: 30px;
    }
    .col-3 img{
      width: 100%;
    }
    .small-container{
      max-width: 1080px;
      margin: auto;
      padding-left: 25px;
      padding-right: 25px;
    }
    .col-4{
      flex-basis: 25%;
      padding: 10px;
      min-width: 200px;
      margin-bottom: 50px;
      transition: 0.5s;
    }
    .col-4 img{
      width: 100%;
    }
    .title{
      text-align: center;
      margin: 0 auto 80px;
      position: relative;
      line-height: 60px;
      color: #5555;
    }
    .title::after{
      content: '';
      background: #ff523b;
      width: 80px;
      height: 5px;
      border-radius: 5px;
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
    }
    h4{
      color: #555;
      font-weight: normal;
    }
    .col4 p{
      font-size: 15px;
    }
    .col-4:hover{
      transform: translateY(-5px);
    }
    .brands{
      margin: 100px auto;
    }
    .col-5{
      width: 160px;
    }
    .col-5 img{
      width: 100%;
      cursor: pointer;
      filter: grayscale(100%);
    }
    .col-5 img:hover{
      filter: grayscale(0);
    }
  </style>
</head>
<body>
  <div class="header">
<div class="row">
        <div class="col-2">
            <h1>Parfem-shop<br>Online parfemi...</h1>
            <p>Originalni parfemi, online prodaja, Parfem-shop online shop. Najbolje cene parfema !</p>
            <a href="shop.php" class="btn">Poruci... &#8594;</a>
        </div>
        <div class="col-2">
            <img src="./slike/sl8.jpeg">
        </div>
    </div>
  </div>

<div class="categories">
  <div class="small-container">
  <div class="row">
    <div class="col-3">
      <img src="./slike/sl1.jpg">
    </div>
    <div class="col-3">
      <img src="./slike/images.jpg">
    </div>
    <div class="col-3">
      <img src="./slike/sl3.jpg" alt="">
    </div>
  </div>
  </div>
</div>

<div class="small-container">
  <h2 class="title">Proizvodi</h2>
  <div class="row">
    <div class="col-4">
      <img src="./slparfemi/sl4.jpg">
      <h4>Nivea AQUA</h4>
      <div class="rating">
      <i class="bi bi-star-fill"></i>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      </div>
      <p></p>
    </div>
    <div class="col-4">
      <img src="./sllice/sl18.jpg">
      <h4>Eucerin</h4>
      <div class="rating">
      <i class="bi bi-star-fill"></i>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      </div>
      <p></p>
    </div>
    <div class="col-4">
      <img src="./sltelo/sl4.jpg">
      <h4>Dove</h4>
      <div class="rating">
      <i class="bi bi-star-fill"></i>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      </div>
      <p></p>
    </div>
    <div class="col-4">
      <img src="./slsminka/sl6.jpg">
      <h4>Loreal</h4>
      <div class="rating">
      <i class="bi bi-star-fill"></i>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      <span class="fas fa-star"></span>
      </div>
      <p></p>
    </div>
  </div>
</div>
<div class="brands">
  <div class="smal-container">
    <div class="row">
      <div class="col-5">
        <img src="./slike/bbanani.png" alt="">
      </div>
      <div class="col-5">
        <img src="./slike/d&g.png" alt="">
      </div>
      <div class="col-5">
        <img src="./slike/gucci.png" alt="">
      </div>
      <div class="col-5">
        <img src="./slike/ch.png" alt="">
      </div>
      <div class="col-5">
        <img src="./slike/bvlgari.jpg" alt="">
      </div>
    </div>
  </div>
</div>

</body>
</html>
