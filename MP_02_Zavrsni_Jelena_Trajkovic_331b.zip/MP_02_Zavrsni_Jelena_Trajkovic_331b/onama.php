<?php include "./menu.php"; ?><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        .section{
            width: 100%;
        }
        .section .conteiner{
            width: 80%;
            display: block;
            margin: 30px auto;
            padding: 50px 0px;
        }
        .conteiner .title{
            width: 100%;
            text-align: center;
            margin-bottom: 50px;
        }
        .conteiner .title h1{
            text-transform: uppercase;
            font-size: 35px;
            color: #88941e;
        }
        .conteiner .title h1::after{
            content: "";
            height: 5px;
            width: 100px;
            background-color: #c4d156;
            border-radius: 25px;
            display: block;
            margin: auto;
        }
        .content{
            float: left;
            width: 55%;
        }
        .image-section{
            float: right;
            width: 40%;
        }
        .image-section img{
            width: 100%;
            height: auto;
        }
        .content .article h3{
            color: #a3a3a3;
            font-size: 17px;
        }
        .content .article p{
            margin-top: 20px;
            font-size: 16px;
            line-height: 1.5;
            color: #333;
        }
        .content .article .button{
            margin-top: 50px;
        }
        .content .article .button a{
            text-decoration: none;
            padding: 8px 25px;
            background-color: #88941e;
            border-radius: 40px;
            color: #fff;
            font-size: 18px;
            letter-spacing: 1.5px;
        }
        .content .article .button a:hover{
            color: #fff;
            background-color: #f28f92;
            transition: 1s ease;
        }
        .conteiner .social{
            width: 100%;
            clear: both;
            margin-top: 50px;
            text-align: center;
            display: inline-block;
        }
        .conteiner .social span{
            color: #fff;
            font-size: 22px;
            height: 45px;
            width: 45px;
            border-radius: 50%;
            line-height: 45px;
            text-align: center;
            background-color: #f28f92;
            margin: 0px 5px;
        }
    </style>
</head>
<body>
    <div class="section">
        <div class="conteiner">
            <div class="title">
                <h1>O nama</h1>
            </div>
            <div class="content">
                <div class="article">
                    <h3>Nega lica</h3>
                        <p>Pogledajte našu ponudu krema za lice, antirid krema, maski za lice, sredstva za čišćenje lica...
                        <a href="lice.php">Lice</a>
                        </p>
                        <h3>Mleka i losioni za telo</h3>
                        <p>Izaberite naše neverovatne losione za telo u vašem omiljenom mirisu i nanesite lako upijajući lagani losion na vašu kožu.</p>
                        <h3>Najbolja sminka za lice, puderi, korektori....</h3>
                        <p>Izaberite najbolji puder za suvu ili masnu kozu, korektor, puder, hajlajter, rumenilo ili bronzer, 
                        prajmer ili fiksator za sminku. Sve za besprekornu sminku ...</p>
                        <h3>PARFEMI</h3>
                        <p>Najraznovrsnija ponuda parfema i najbolje cene na jednom mestu! 
                        Otkrijte novitete u svetu parfema i odaberite sebi savršen miris</p>
                         <div class="button">
                         <a href="proizvod.php">Saznaj vise</a>
                         </div>
                </div>
            </div>
            <div class="image-section">
                <img src="slabout/sl2.jpg">
            </div>
            <div class="social">
                   <a href="#"><span class="fab fa-facebook"></span></a>
                   <a href="#"><span class="fab fa-instagram"></span></a>
                   <a href="#"><span class="fab fa-google"></span></a>
            </div>
        </div>
    </div>
   
</body>
</html>