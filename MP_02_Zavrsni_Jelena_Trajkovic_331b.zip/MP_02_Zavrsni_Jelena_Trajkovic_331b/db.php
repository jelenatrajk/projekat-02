<?php 
$uname = "root";
$dbpass = "";
$host = "localhost";
$db = "baza_projekta";

$conn = mysqli_connect("$host" , "$uname" , "$dbpass" , "$db") or die("db error connection");

?>